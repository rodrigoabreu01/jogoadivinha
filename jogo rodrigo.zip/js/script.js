let numeroRandomico = Math.floor(Math.random() * 100) + 1;
let palpite = [];


formulario.onsubmit = () => {
    event.preventDefault();
    if(input.value < numeroRandomico){
        alert("É menor!");

    }else{
        alert("é maior!");
    
    }
    palpite.push(input.value);
    resultPalpites.innerHTML = palpite.join(' - ');
    formulario.reset();
}